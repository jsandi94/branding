<?php
return [
        'BRAND_LOGO' => './my_images/cdp_logo.png',
        'BRAND_LOGO_SIDEBAR' => './my_images/cdp_logo_sidebar.png',
        'BRAND_LOGO_SIDEBAR_COMPACT' => './my_images/cdp_logo_sidebar_compact.png',
        'BRAND_FOOTER' => '© CDP Energy',
        'BRAND_HELP_URL' => 'https://cdpenergy.com'
];
